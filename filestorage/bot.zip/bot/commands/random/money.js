const commando = require("discord.js-commando");

class getmoney extends commando.Command {

    constructor(client) {

        super(client, {
            name: "money",
            group: "random",
            memberName: "money",
            description: "tells you how much money you have"
        });
    }

    async run(message, args) {

    message.reply("Soon to be implemented!");

    }

}

module.exports = getmoney;