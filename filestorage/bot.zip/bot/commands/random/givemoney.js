/*const commando = require("discord.js-commando");

class givemoney extends commando.Command {

    constructor(client) {

        super(client, {
            name: "givemoney",
            group: "random",
            memberName: "givemoney",
            description: "gives someone money"
        });
    }

    async run(message, args) {

        if(message.member.role.has("367306995830620161")) {
            message.replay("you haz permission!");
          } else {
            message.replay("you no haz permission");
          }

    }
    
}

module.exports = givemoney;
*/