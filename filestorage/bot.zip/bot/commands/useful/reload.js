/*const commando = require("discord.js-commando");

class reload extends commando.Command {

    constructor(client) {

        super(client, {
            name: "reload",
            group: "utility",
            memberName: "reload",
            description: "reloads the bot"
        });
    }

    async run(message, args) {

    if(message.member.hasPermission("administrator")) {

        bot.reload;

    }

    }

}

module.exports = reload;
*/