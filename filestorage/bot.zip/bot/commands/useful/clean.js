const commando = require("discord.js-commando");

class clear extends commando.Command {

    constructor(client) {

        super(client, {
            name: "clean",
            group: "useful",
            memberName: "clean",
            description: "Clears a amount of text",
            args: [
                {

                    key: "arg",
                    prompt: "how many lines should be deleted?",
                    type: "string"

            }
            ]
        });
    }

    async run(message, {arg}) {

        if (message.channel.isPrivate) {

            message.channel.sendMessage("This channel is private!");

        } else {

    if (message.member.hasPermission("MANAGE_MESSAGES")) {

        message.delete();

        var numer = parseInt(arg);

        message.channel.sendMessage("!clear " + numer);

    } else {

        message.channel.sendMessage("You don't have permission!")

    
} 
}

}
}

module.exports = clear;
