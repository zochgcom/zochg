const commando = require("discord.js-commando");
const bot = new commando.Client();

class rig extends commando.Command {

    constructor(client) {

        super(client, {
            name: "rig",
            group: "useful",
            memberName: "rig",
            description: "Gives download link to RIG"
        });
    }

    async run(message, args) {

        const bot = new commando.Client();

        message.reply("https://zochgcom.github.io/zochg/Games/RIG/RIG.exe/");
        console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + " used the command RIG!")


    }

}

module.exports = rig;
