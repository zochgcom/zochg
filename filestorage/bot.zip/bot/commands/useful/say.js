const commando = require("discord.js-commando");

class say extends commando.Command {

    constructor(client) {

        super(client, {
            name: "say",
            group: "useful",
            memberName: "say",
            description: "Says a text that you give him",
            args: [
                {

                    key: "arg",
                    prompt: "What should be said?",
                    type: "string"

            }
            ]
        });
    }

    async run(message, {arg}) {

    if (message.member.hasPermission("MANAGE_MESSAGES")) {

        message.delete();

        message.channel.sendMessage(arg.replace("/new ", "\n"));

    } else {

        message.channel.sendMessage("You don't have permission!")
        console.log(message.author + "Tried the say command without permission".bold.red)

    }


}

}

module.exports = say;
