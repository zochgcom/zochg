const commando = require("discord.js-commando");

const bot = new commando.Client({
    commandPrefix: 'zlave',
    owner: ["246573465031802881", "244509769665085442"]
    });

class cls extends commando.Command {

    constructor(client) {

        super(client, {
            name: "cls",
            group: "admin",
            memberName: "cls",
            description: "Clears the console (owner only)!"
        });
    }

    async run(message, args) {

if (bot.isOwner(message.author)) {

        console.clear();
        message.delete();

    console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + " (" + message.author.username + "#" + message.author.discriminator + ")" + " Cleared the console")
} else {

    message.channel.sendMessage("Only the bot owner may do this!")

}
}

}

module.exports = cls;

