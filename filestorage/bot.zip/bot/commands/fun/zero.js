const commando = require("discord.js-commando");

class zero extends commando.Command {

    constructor(client) {

        super(client, {
            name: "zero",
            group: "fun",
            memberName: "zero",
            description: "ZEROOOOOO!"
        });
    }

    async run(message, args) {

    message.channel.send("\nZ\n　 E\n　　　 R\n　　　　 O\n　　　　　o\n　　　　　 o\n　　　　　o\n　　　　 。\n　　　 。\n　　　.\n　　　.\n　　　 .\n　　　　.");
    console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + " used the command ZERO!")
    }

}

module.exports = zero;

