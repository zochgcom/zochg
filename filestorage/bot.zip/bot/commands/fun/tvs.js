const commando = require("discord.js-commando");

const bot = new commando.Client({
    commandPrefix: 'zlave',
    owner: ["246573465031802881", "244509769665085442"]
    });

class tvs extends commando.Command {

    constructor(client) {

        super(client, {
            name: "tvs",
            group: "fun",
            memberName: "tvs",
            description: "Short comic about talent and skill"
        });
    }

    async run(message, args) {

        message.channel.sendMessage("", {
            file: "./assets/images/tvs.png"
        });
    console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + " used the command ZERO!")
    }

}

module.exports = tvs;

