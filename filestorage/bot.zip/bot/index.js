//const Discord = require("discord.js");
const commando = require("discord.js-commando");;
const colors = require("colors")

const bot = new commando.Client({
    commandPrefix: 'zlave',
    owner: ["246573465031802881", "244509769665085442"]
    });

bot.registry.registerGroup("useful", "Useful commands");
bot.registry.registerGroup("fun", "Fun commands");
bot.registry.registerGroup("random", "Money related commands");
bot.registry.registerGroup("admin", "Admin commands");
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + "/commands");

bot.login("MzYwMDE1NDg4MjMyODQ5NDA5.DL4Wpw.mDV_N01tQQqe1hBcRe6E7HVCmdE");

var bots = ["81026656365453312", "159985870458322944", "172002275412279296", "155149108183695360"];

var up = new Date();

console.log("[" + up.getHours() + ":" + up.getMinutes() + ":" + up.getSeconds() + "]" + "bot is up and running")

bot.on("message", message => {

   if (message.author.id == "360015488232849409") {

} else if (message.guild) {

    if (bots.includes(message.author.id)) {
        
            console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + " " + "BOT".bgCyan + ": '" + message.cleanContent.green + "'| " + message.channel.name.red)
        
        } else {
    console.log("[" + message.createdAt.getHours() + ":" + message.createdAt.getMinutes() + ":" + message.createdAt.getSeconds() + "]" + message.author.username + ": '" + message.cleanContent.green + "'| " + message.channel.name.red)
        }
}

});