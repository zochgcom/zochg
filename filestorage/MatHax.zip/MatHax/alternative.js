input = document.getElementById("alternative");
output = document.getElementById("answer");

document.getElementById("calculate").onclick = function() {update()};

function update() {
input2 = input.innerText.replace("⋅","*").replace("−","-").replace(":","/").replace("=","");
output = input2;
}