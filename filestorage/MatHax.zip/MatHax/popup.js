// document.getElementsByClassName("mrow")[7].children[0].innerText.replace("⋅","*").replace("=","").replace("−","-").replace(":","/")


/*document.getElementById('calculate').addEventListener('click', function() {
    chrome.tabs.query({ active: true, currentWindow: true}, function(activeTabs) {
        // WAY 1
        chrome.tabs.executeScript(activeTabs[0].id, { code: 'alert("hola")' });
    });
});*/

    document.getElementById("calculate").onclick = function() {bich()};
    function bich() {
        chrome.tabs.query({ active: true, currentWindow: true}, function(activeTabs) {
            // WAY 1
            chrome.tabs.executeScript(activeTabs[0].id, { code: `
            function bich() {
            for (var i=0;i<document.getElementsByClassName("mrow").length;i++) {
                var equa = document.getElementsByClassName("mrow")[i].innerText.replace("⋅","*").replace("−","-").replace(":","/").replace("=","");
                document.getElementsByClassName("mrow")[i].innerText = eval(equa.replace("\u22c5","*").replace("\u2212","-").replace(":","/").replace("=",""));
            }
            for (var i=0;i<document.getElementsByClassName("questionText").length;i++) {
                var equa = document.getElementsByClassName("questionText")[i].innerText.replace(",",".").replace(/[^0-9+-/*.]/g,"");
                var euqa = equa;
                document.getElementsByClassName("questionText")[i].innerText = eval(equa.replace(/[^0-9+-/*.]/g,""));
                document.getElementsByClassName("answerInput")[0].value = eval(equa.replace(/[^0-9+-/*.]/g,""));
            }}
            setInterval(bich,100);
            `});
        });	
    }
    