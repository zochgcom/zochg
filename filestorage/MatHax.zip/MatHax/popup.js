// document.getElementsByClassName("mrow")[7].children[0].innerText.replace("⋅","*").replace("=","").replace("−","-").replace(":","/")


/*document.getElementById('calculate').addEventListener('click', function() {
    chrome.tabs.query({ active: true, currentWindow: true}, function(activeTabs) {
        // WAY 1
        chrome.tabs.executeScript(activeTabs[0].id, { code: 'alert("hola")' });
    });
});*/
 //By SpoodyTheOne
   /* var box = document.getElementById("box");
 //By SpoodyTheOne
    chrome.storage.sync.get("autoAnswer",function(data) {
        if (data.autoAnswer == true) {
        box.checked = true;
        } else {
        box.checked = false;
        }
    });
 //By SpoodyTheOne
    box.onclick = function() {
        chrome.storage.sync.set({autoAnswer: box.checked}, function() {
            console.log("AutoAnswer = " + box.checked);
        });
    }*/
 //By SpoodyTheOne
	
	var hack;
	
	document.addEventListener('DOMContentLoaded', function() {
	hack = document.getElementById("hack");
		
    hack.addEventListener("click",bich);
	
  });
    function bich() {
        chrome.tabs.query({ active: true, currentWindow: true}, function(activeTabs) {
            chrome.tabs.executeScript(activeTabs[0].id, { code: `
            function bich() {
                numbers = document.getElementsByClassName("mn");
                for (i=0;i<numbers.length;i++) {
                    if (numbers[i].style.fontSize == "70.7%" && !numbers[i].innerText.startsWith("**")) {
                        numbers[i].innerText = "**" + numbers[i].innerText;
                    }
                }
          for (var i=0;i<document.getElementsByClassName("mrow").length;i++) {
                var equa = document.getElementsByClassName("mrow")[i].innerText.replace("\u22c5","*").replace("\u22c5","*").replace("\u22c5","*").replace("−","-").replace("\u2212","-").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".");
                document.getElementsByClassName("mrow")[i].innerText = eval(equa.replace("\u22c5","*").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".")).toFixed(3);
            }}
            bich();
            setInterval(bich,100);  //By SpoodyTheOne
            clearInterval(bitch); //By SpoodyTheOne
            `});
            chrome.tabs.executeScript(activeTabs[0].id, { code: `
           /* function bich() {
                numbers = document.getElementsByClassName("mn");
                for (i=0;i<numbers.length;i++) {
                    if (numbers[i].style.fontSize == "70.7%" && !numbers[i].innerText.startsWith("**")) {
                        numbers[i].innerText = "**" + numbers[i].innerText;  //By SpoodyTheOne
                    }
                }
          for (var i=0;i<document.getElementsByClassName("mrow").length;i++) {
                var equa = document.getElementsByClassName("mrow")[i].innerText.replace("\u22c5","*").replace("\u22c5","*").replace("\u22c5","*").replace("−","-").replace("\u2212","-").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".");
                document.getElementsByClassName("mrow")[i].innerText = eval(equa.replace("\u22c5","*").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".")).toFixed(3);
            } 
            for (var i=0;i<document.getElementsByClassName("mrow").length;i++) {  //By SpoodyTheOne
                var equa = document.getElementsByClassName("mrow")[i].innerText.replace("\u22c5","*").replace("\u22c5","*").replace("\u22c5","*").replace("−","-").replace("\u2212","-").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".");
                document.getElementsByClassName("mrow")[i].innerText = eval(equa.replace("\u22c5","*").replace("\u2212","-").replace(":","/").replace("=","").replace(",",".").replace(",",".").replace(",",".").replace(",",".")).toFixed(3);
            }}           
            /*for (var i=0;i<document.getElementsByClassName("questionText").length;i++) {
                var equa = document.getElementsByClassName("questionText")[i].innerText.replace(",",".").replace(/[^0-9+-/*.]/g,"");
                var euqa = equa;
                document.getElementsByClassName("questionText")[i].innerText = eval(equa.replace(/[^0-9+-/*.]/g,""));
                document.getElementsByClassName("answerInput")[0].value = eval(equa.replace(/[^0-9+-/*.]/g,"")).replace(".",",");
            }}*/
            bich();
            bitch = setInterval(bich,100);*/  //By SpoodyTheOne
            `});
        });
    }
    