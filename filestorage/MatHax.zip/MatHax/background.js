chrome.runtime.onInstalled.addListener(function() {
    console.log("MatHax Online, v2")
    chrome.storage.sync.set({autoAnswer: false}, function() {
      console.log("AutoAnswer = false.");
    });
  });