chrome.runtime.onInstalled.addListener(function() {
    console.log("MatHax Online, v2")
  });