const commando = require("discord.js-commando");
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });

const fs = require("fs");
const numeral = require("numeral")

// First, this must be at the top level of your code, **NOT** in any event!
const talkedRecently = new Set();

class bork extends commando.Command {
    
        constructor(client) {
    
            super(client, {
                name: "coin",
                group: "default",
                memberName: "coin",
                aliases: ["coinflip", "bet", "flip"],
                description: "flip coin to get Bork coin!",     
                throttling: {
                  usages: 2,
                  duration: 10
                }  ,
                args: [{
                  key: "amount",
                  prompt: "How much yu bet for?",
                  type: "string"

                }, 
              {
                key: "bet",
                prompt: "doggo or kitty (small letter pls)",
                type: "string"
              }]  
            });
        }
    
        async run(message, { amount, bet}) {


if (message.author.bot) return; // always ignore bots!

          // Inside your message event, this code will stop any command during cooldown.
// Should be placed after your code that checks for bots & prefix, for best performance
if (Number.isInteger(parseInt(amount))) {
  
  if (amount < 5) {
    message.channel.send({embed: {
      color: 0xff0000,
      author: {
        name: "Bork flip"
      },
      fields: [{
          name: "**Minimum bet is 5 bork coin**",
          value: "*Yu cant cheet BORKBOT!*"
        }
      ],
      timestamp: new Date(),
      footer: {
        text: "© BORKBOT 2017"
      }
    }
  });
  }

if (talkedRecently.has(message.author.id + message.guild)) {

  message.channel.send({embed: {
    color: 0xff0000,
    author: {
      name: "Bork flip"
    },
    fields: [{
        name: "**You has cooldown on Bork flip**",
        value: "*Yu cant cheet BORKBOT!*"
      }
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});

} else {


// Adds the user to the set so that they can't talk for 2.5 seconds
talkedRecently.add(message.author.id + message.guild);
setTimeout(() => {
// Removes the user from the set after 2.5 seconds
talkedRecently.delete(message.author.id + message.guild);
}, 0);

    let money = JSON.parse(fs.readFileSync("./money.json", "utf8"));

  if (money[message.author.id + message.guild].money >= amount) {

    money[message.author.id + message.guild].money -= amount;
    var sideInt = Math.floor(Math.random() * 4) + 1;
    if (sideInt > 2) {
      var side = "doggo"
    } else if (sideInt <= 2) {
      var side = "kitty"
    } 

    if (bet == side) {

  message.channel.send({embed: {
    color: 0x33ff33,
    author: {
      name: "Bork flip"
    },
    image: {
      url: "https://spoodytheone.github.io/cookies/" + side + ".png"
    },
    fields: [{
        name: "**You choos** __" + bet + "__",
        value: "*Coin land on* __" + side + "__*, Yu win \n__" + numeral(amount).format("0a") + "__ Bork coin*"
      },
      {
        name: "**Yu naw hav**",
        value: "__" + numeral(money[message.author.id + message.guild].money + (amount*2)).format("0a") + "__ *Bork coin*"
      }
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});

money[message.author.id + message.guild].money += parseInt(parseInt(amount) + parseInt(amount));
    } else {

      message.channel.send({embed: {
        color: 0xff3333,
        author: {
          name: "Bork flip"
        },
        image: {
          url: "https://spoodytheone.github.io/cookies/" + side + ".png"
        },
        fields: [{
            name: "**You choos** __" + bet + "__",
            value: "*Coin land on* __" + side + "__*, Yu loos \n__-" + amount + "__ Bork coin*"
          },
          {
            name: "**Yu naw hav**",
            value: "__" + numeral(money[message.author.id + message.guild].money + (amount*2)).format("0a") + "__ *Bork coin*"
          }
        ],
        timestamp: new Date(),
        footer: {
          text: "© BORKBOT 2017"
        }
      }
    });
  }
  } else {

    message.channel.send({embed: {
      color: 0xff3333,
      author: {
        name: "Bork flip"
      },
      fields: [{
          name: "**Poor human**",
          value: "*Yu too poor to do this*"
  }
      ],
      timestamp: new Date(),
      footer: {
        text: "© BORKBOT 2017"
      }
    }
  });
  }

  // And then, we save the edited file.
  fs.writeFile("./money.json", JSON.stringify(money), (err) => {
    if (err) console.error(err)
  });
}
} else {

  message.channel.send({embed: {
    color: 0xff3333,
    author: {
      name: "Bork flip"
    },
    fields: [{
        name: "**Wron input**",
        value: amount + "/" + bet + " *Iz not allow*"
}
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});

}

}

}

module.exports = bork;

