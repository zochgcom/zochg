const commando = require("discord.js-commando");
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });

const fs = require("fs");

// First, this must be at the top level of your code, **NOT** in any event!
const talkedRecently = new Set();

class bork extends commando.Command {
    
        constructor(client) {
    
            super(client, {
                name: "sit",
                group: "default",
                memberName: "sit",
                aliases: ["daily", "freemoney", "bork"],
                description: "Givs u daily bork coins!",     
                throttling: {
                  usages: 2,
                  duration: 10
                }    
            });
        }
    
        async run(message, {arg}) {


if (message.author.bot) return; // always ignore bots!

          // Inside your message event, this code will stop any command during cooldown.
// Should be placed after your code that checks for bots & prefix, for best performance

if (talkedRecently.has(message.author.id + message.guild)) {

  message.channel.send({embed: {
    color: 0xff0000,
    author: {
      name: "Daily borks"
    },
    fields: [{
        name: "**You has alredy claimed yu daily borks!**",
        value: "*Yu cant cheet BORKBOT!*"
      }
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});

} else {


// Adds the user to the set so that they can't talk for 2.5 seconds
talkedRecently.add(message.author.id + message.guild);
setTimeout(() => {
// Removes the user from the set after 2.5 seconds
talkedRecently.delete(message.author.id + message.guild);
}, 648000);

    let money = JSON.parse(fs.readFileSync("./money.json", "utf8"));

  // if the money don"t exist, init to 0;
  if (!money[message.author.id + message.guild]) money[message.author.id + message.guild] = {
    money: 0,
  };

  money[message.author.id + message.guild].money += 100;

  message.channel.send({embed: {
    color: 0x33ff33,
    author: {
      name: "Daily borks"
    },
    fields: [{
        name: "**You has claim yu daily bork coin**",
        value: "*Yu now hav ___" + money[message.author.id + message.guild].money + "___ Bork coin*"
      }
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});

  // And then, we save the edited file.
  fs.writeFile("./money.json", JSON.stringify(money), (err) => {
    if (err) console.error(err)
  });
}
}

}

module.exports = bork;

