const commando = require("discord.js-commando");
const client = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });
    const fs = require("fs");

class bork extends commando.Command {

    constructor(client) {

        super(client, {
            name: "level",
            group: "default",
            memberName: "level",
            description: "what levl r u?",
        });
    }

    async run(message, {arg}) {

      if (message.guild) {
        let points = JSON.parse(fs.readFileSync("./points.json", "utf8"));

        if (!points[message.author.id + message.guild]) {
         points[message.author.id + message.guild] = {
          points: 0,
          level: 0
        }
      } else {

        message.channel.send({embed: {
            color: 0x2222ff,
            author: {
              name: "Levels"
            },
            image: {
              url: "https://spoodytheone.github.io/cookies/" + parseInt(points[message.author.id + message.guild].points / (((points[message.author.id + message.guild].level + 1) * 100)) * 100) + ".png"
            },
            fields: [{
                name: "**You levl**",
                value: points[message.author.id + message.guild].level,
              },
              {
              name: "**Yu hav dis many point**",
              value: points[message.author.id + message.guild].points
              },
              {
                name: "**Yu r this clos to levl up**",
                value: parseInt(points[message.author.id + message.guild].points / (((points[message.author.id + message.guild].level + 1) * 100)) * 100) + "%"
              }
            ],
            timestamp: new Date(),
            footer: {
              text: "© BORKBOT 2017"
            }
          }
        });
      }

}  else {
  
  message.channel.send({embed: {
    color: 0xff0000,
    author: {
      name: "Levels"
    },
    fields: [{
        name: "**Yu only use levl in servr**",
        value: "Not in privat",
      }
    ],
    timestamp: new Date(),
    footer: {
      text: "© BORKBOT 2017"
    }
  }
});
        
      }

    }

}

module.exports = bork;
