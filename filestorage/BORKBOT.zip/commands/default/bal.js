const commando = require("discord.js-commando");
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });
const numeral = require("numeral");

const fs = require("fs");
let cooldowns = JSON.parse(fs.readFileSync("./money.json", "utf8"));

class bork extends commando.Command {
    
        constructor(client) {
    
            super(client, {
                name: "bal",
                group: "default",
                memberName: "bal",
                description: "Givs u daily bork coins!",
                aliases: ["balance", "money", "borks", "points", "coins"]
            });
        }
    
        async run(message, {arg}) {

          let points = JSON.parse(fs.readFileSync("./money.json", "utf8"));

          if (!points[message.author.id + message.guild]) {
            points[message.author.id + message.guild] = {
              money: 0
           }

           message.channel.send({embed: {
            color: 0xff9999,
            author: {
              name: "Balance"
            },
            fields: [{
                name: "**You has**",
                value: "no Bork coin"
              }
            ],
            timestamp: new Date(),
            footer: {
              text: "© BORKBOT 2017"
            }
          }
        });

         } else {

          if (points[message.author.id + message.guild].money == 0) {
            message.channel.send({embed: {
              color: 0xff9999,
              author: {
                name: "Balance"
              },
              fields: [{
                  name: "**You has**",
                  value: "no Bork coin"
                }
              ],
              timestamp: new Date(),
              footer: {
                text: "© BORKBOT 2017"
              }
            }
          });
          } else {
          
                  message.channel.send({embed: {
                      color: 0x99ff99,
                      author: {
                        name: "Balance"
                      },
                      fields: [{
                          name: "**You has**",
                          value: numeral(points[message.author.id + message.guild].money).format("0a") + " Bork coin"
                        }
                      ],
                      timestamp: new Date(),
                      footer: {
                        text: "© BORKBOT 2017"
                      }
                    }
                  });

                }

}

        }

}

module.exports = bork;

