const commando = require("discord.js-commando");
const client = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });

class bork extends commando.Command {

    constructor(client) {

        super(client, {
            name: "cmds",
            group: "default",
            memberName: "cmds",
            description: "Gives you a list of commands",
        });
    }

    async run(message, {arg}) {

        message.author.send({embed: {
            color: 0xff0000,
            author: {
              name: "Command list"
            },
            fields: [{
                name: "bal, balance, money",
                value: "*Shows yu' Bork coin*",
              },
              {
                name: "**coin, flip, coinflip**",
                value: "*Flip coin to win bork. or loos*"
              },
              {
                name: "**daily, sit, freemoney**",
                value: "*Givs u free Bork coins evry 18 hours*"
                },
                {
                  name: "**level**",
                  value: "*Show yu' levl!*"
                  },
              {
                name: "**Invite**",
                value: "*If yu want BORKBOT yu clik [here!](https://discordapp.com/oauth2/authorize?client_id=387516208611590145&scope=bot&permissions=2146958591)*"
              }
            ],
            timestamp: new Date(),
            footer: {
              text: "© BORKBOT 2017"
            }
          }
        });


}

}

module.exports = bork;
