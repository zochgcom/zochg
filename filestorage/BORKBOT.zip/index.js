//const Discord = require("discord.js");
const commando = require("discord.js-commando");;
const colors = require("colors")
const fs = require("fs");
let points = JSON.parse(fs.readFileSync("./points.json", "utf8"));
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });
    const talkedRecently = new Set();
    const config = require("./config.json");

bot.registry.registerGroup("default", "Commands");
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + "/commands");

bot.login(config.token2);
var up = new Date();
console.log("[" + up.getHours() + ":" + up.getMinutes() + ":" + up.getSeconds() + "]" + "bot is up and running");

bot.on("ready", () => {

  bot.username = config.username;
  bot.user.setStatus("available"); // Can be 'available', 'idle', 'dnd', or 'invisible'
  bot.user.setPresence({
    game: {
        name: config.presence + " | " + "BORKBOT v" + config.version,
        type: 0
    }
});

});

bot.on("message", message => {

  if (talkedRecently.has(message.author.id + message.guild)) {

      } else {

  if (message.author.bot) return; // always ignore bots!
  if (message.guild) {


    talkedRecently.add(message.author.id + message.guild);
setTimeout(() => {

talkedRecently.delete(message.author.id + message.guild);
}, 30000);

  if (talkedRecently.has(message.author.id)) return;

  // if the points don"t exist, init to 0;
  if (!points[message.author.id + message.guild]) points[message.author.id + message.guild] = {
    points: 0,
    level: 0
  };
  points[message.author.id + message.guild].points += Math.floor(Math.random() * 10) + 1;

  if (points[message.author.id + message.guild].points >= (points[message.author.id + message.guild].level + 1) * 100) {

    points[message.author.id + message.guild].level++;
    message.channel.sendMessage(message.author.username + " Just reached level " + points[message.author.id + message.guild].level + "!")
	points[message.author.id + message.guild].points = 0;

  }

  // And then, we save the edited file.
  fs.writeFile("./points.json", JSON.stringify(points), (err) => {
    if (err) console.error(err)
  });
}

  }
});