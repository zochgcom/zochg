//const Discord = require("discord.js");
const commando = require("discord.js-commando");;
const colors = require("colors")
const fs = require("fs");
let points = JSON.parse(fs.readFileSync("./points.json", "utf8"));
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });

bot.registry.registerGroup("default", "Commands");
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + "/commands");

bot.login("Mzg3NTE2MjA4NjExNTkwMTQ1.DQfmUQ.P7T5jkpKkGFWz4Vg_GtNBAs5qr4");
var up = new Date();
console.log("[" + up.getHours() + ":" + up.getMinutes() + ":" + up.getSeconds() + "]" + "bot is up and running");

bot.on("ready", () => {

  bot.user.setStatus("available"); // Can be 'available', 'idle', 'dnd', or 'invisible'
  bot.user.setPresence({
    game: {
        name: 'Type >cmds',
        type: 0
    }
});

});

bot.on("message", message => {
if (message.author.bot) return; // always ignore bots!

  // if the points don"t exist, init to 0;
  if (!points[message.author.id + message.guild]) points[message.author.id + message.guild] = {
    points: 0,
    level: 0
  };
  points[message.author.id + message.guild].points += Math.floor(Math.random() * 10) + 1;

  if (points[message.author.id + message.guild].points >= (points[message.author.id + message.guild].level + 1) * 100) {

    points[message.author.id + message.guild].level++;
    message.channel.sendMessage(message.author.username + " Just reached level " + points[message.author.id + message.guild].level + "!")

  }

  // And then, we save the edited file.
  fs.writeFile("./points.json", JSON.stringify(points), (err) => {
    if (err) console.error(err)
  });
});