const commando = require("discord.js-commando");
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });
    const fs = require("fs");

class bork extends commando.Command {

    constructor(client) {

        super(client, {
            name: "presence",
            group: "default",
            memberName: "resence",
            description: "sets the presence of BORKBOT",
            args: [{

              key: "arg",
              prompt: "What should the presence be set to?",
              type: "string"

            }]
        });
    }

    async run(message, {arg}) {

      if (bot.isOwner(message.author)) {}

        message.channel.send({embed: {
            color: 0xff0000,
            author: {
              name: "Levels"
            },
            fields: [{
                name: "**You sat the presence of BORKBOT to**",
                value: arg,
              }
            ],
            timestamp: new Date(),
            footer: {
              text: "© BORKBOT 2017"
            }
          }
        });

        bot.on('ready', () => {
          bot.user.setStatus('available') // Can be 'available', 'idle', 'dnd', or 'invisible'
          bot.user.setPresence({
              game: {
                  name: arg,
                  type: 0
              }
          });
      });


}

}

module.exports = bork;
