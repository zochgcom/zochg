const commando = require("discord.js-commando");
const bot = new commando.Client({
    commandPrefix: '>',
    owner: ["246573465031802881", "244509769665085442"]
    });

const fs = require("fs");
let cooldowns = JSON.parse(fs.readFileSync("./money.json", "utf8"));

class bork extends commando.Command {
    
        constructor(client) {
    
            super(client, {
                name: "bal",
                group: "default",
                memberName: "bal",
                description: "Givs u daily bork coins!",
                aliases: ["balance", "money", "borks", "points"]
            });
        }
    
        async run(message, {arg}) {

          let points = JSON.parse(fs.readFileSync("./money.json", "utf8"));

          if (!points[message.author.id + message.guild]) {
            points[message.author.id + message.guild] = {
              money: 0
           }
         } else {
          
                  message.channel.send({embed: {
                      color: 0x99ff99,
                      author: {
                        name: "Balance"
                      },
                      fields: [{
                          name: "**You has**",
                          value: points[message.author.id + message.guild].money + " Bork coin"
                        }
                      ],
                      timestamp: new Date(),
                      footer: {
                        text: "© BORKBOT 2017"
                      }
                    }
                  });

                }

}

}

module.exports = bork;

